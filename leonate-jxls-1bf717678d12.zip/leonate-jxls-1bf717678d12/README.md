Jxls Core
================

Overview
--------
[Jxls](http://jxls.sf.net/) is a small and simple to use Java library for Excel generation.

Jxls abstracts Excel generation from underlying java-to-excel low-level processing library.

Jxls uses a special markup in Excel templates to define output formatting and data layout.

The module contains source code for [Jxls Core](http://jxls.sf.net/)
